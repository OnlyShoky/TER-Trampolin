const char MAIN_page_vide[] = R"=====(
<!DOCTYPE html>
<html>

<head>
    <title>Mesures de temps de vol</title>
    <meta charset="UTF-8">

    <style>
        body {
            width: 600px;
            margin-left: auto;
            margin-right: auto;
            margin-top: 0px;
        }
    </style>
</head>

<body>
    <h2>Il n'y a pas de mesures</h2>
</body>

</html>
)=====";