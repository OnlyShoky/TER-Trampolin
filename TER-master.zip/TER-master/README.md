# Midair Timing System for Trampoline 

Utilisation du NodeMCU v3. Doc:
https://docs.zerynth.com/latest/official/board.zerynth.nodemcu3/docs/index.html

Dépendance :
- librairies Arduino
- github.com/ThingPulse/esp8266-oled-ssd1306 (SSD1306 library)

## IDE 
PlatformIO avec VS Code (Atom est aussi possible).

Répartition des taches : https://github.com/Alexdesaint/TER/projects/1
